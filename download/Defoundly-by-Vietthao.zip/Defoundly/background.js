chrome.webRequest.onBeforeRequest.addListener(
  details => {
    console.log(details)
    return {
      redirectUrl: details.url.replace('web.neargroup.me/ng', 'profoundly.thao.pw')
    };
  }, {
    urls: ["https://web.neargroup.me/ng/GetAllMessages*"]
  }, ["blocking"]
);

chrome.runtime.onInstalled.addListener(details => {
  switch (details.reason) {
    case 'install':
      chrome.tabs.create({
        url: 'https://www.facebook.com/groups/j2team.community/'
      });
      break;
  }
});